/*
14. Crie um ficheiro de script para inserir dois departamentos da empresa: Comercial e Administra��o. D�lhe o nome Vacations_Inserir_Nome.sql.
*/




-- Mudan�a do contexto da database
USE [Vacations_PauloMelo];
GO




-- Inser��o dos departamentos
INSERT INTO [dbo].[Department] (Department)
VALUES
	('Comercial'),
	('Administra��o');
GO




/*
16. Use o ficheiro criado anteriormente, Vacations_Inserir_Nome.sql , para inserir dois novos formul�rios
*/




-- Inser��o do Department
INSERT INTO [dbo].[Department] (Department)
VALUES
	('Financeiro');		-- Departamento Administrativo n�o foi inserido porque Administra��o j� existe
GO




-- Inser��o relativa � VacationRequest
INSERT INTO [dbo].[VacationRequest] (RequestDate, ApprovalDate, ManagerCode, EmployeeCode)
VALUES
	('2019-02-26', '2019-03-06', 'PT-PRT-HR-000003', 'PT-LIS-FI-000083'),		-- Acrescentei um 0 ao EmployeeCode para se enquadrar com o formato
	('2019-03-04', '2019-03-13', 'PT-PRT-HR-000003', 'PT-BRG-AD-000100');
GO




-- Inser��o relativa � VacationPeriod
-- Usei o # como PeriodId (PK autom�tica, o que impossibilita cumprir por completo este exerc�cio)
INSERT INTO [dbo].[VacationPeriod] (RequestId, StartDate, EndDate, TotalDays, Approval)
VALUES
	(2, '2019-04-15', '2019-04-19', 6, 0),
	(2, '2019-07-29', '2019-08-21', 27, 1),
	(3, '2019-02-04', '2019-02-15', 12, 1),
	(3, '2019-07-29', '2019-07-31', 3, 1),
	(3, '2019-12-23', '2019-12-31', 9, 0);
GO




-- Inser��o relativa a Manager
INSERT INTO [dbo].[Manager] (RequestId, DepartmentId, ManagerCode, ManagerFirstName, ManagerMiddleName, ManagerSurname)
VALUES
	(2, 1, 'PT-PRT-HR-000003', 'M�rio', '', 'Ramos'),		-- N�o tem nome do meio
	(3, 1, 'PT-PRT-HR-000003', 'M�rio', '', 'Ramos');
GO




-- Inser��o relativa a Employee
INSERT INTO [dbo].[Employee] (RequestId, DepartmentId, EmployeeCode, EmployeeFirstName, EmployeeMiddleName, EmployeeSurname)
VALUES
	(2, 5, 'PT-LIS-FI-000083', 'Rui', 'Pina de', 'Oliveira'),
	(3, 4, 'PT-BRG-AD-000100', 'Maria', 'Teresa Vale dos', 'Santos');
GO




-- Inser��o relativa � ReportingStructure
INSERT INTO [dbo].[ReportingStructure] (EmployeeId, ManagerId)
VALUES
	(2, 2),
	(3, 3);		-- Redund�ncia no Manager
GO
