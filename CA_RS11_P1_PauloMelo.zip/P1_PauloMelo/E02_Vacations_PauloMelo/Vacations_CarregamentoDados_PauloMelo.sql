/*
11. Crie o ficheiro de script Vacations_CarregamentoDados_Nome.sql para carregar os dados iniciais das 
tabelas. Como fonte, use os dados normalizados do Excel.
*/




-- Mudan�a do contexto da database
USE [Vacations_PauloMelo];
GO




-- Carregamento dos dados iniciais da tabela Department
INSERT INTO [dbo].[Department] (Department)
VALUES
	('Recursos Humanos'),
	('Tecnologias de Informa��o');
GO




-- Carregamento dos dados iniciais da tabela VacationRequest
INSERT INTO [dbo].[VacationRequest] (RequestDate, ApprovalDate, ManagerCode, EmployeeCode)
VALUES
	('2019-02-25', '2019-03-04', 'PT-PRT-HR-000012', 'PT-PRT-TI-000120');
GO




-- Carregamento dos dados iniciais da tabela VacationPeriod
INSERT INTO [dbo].[VacationPeriod] (RequestId, StartDate, EndDate, TotalDays, Approval)
VALUES
	(1, '2019-03-04', '2019-03-08', 5, 1),
	(1, '2019-07-29', '2019-08-16', 15, 1),
	(1, '2019-12-23', '2020-01-03', 8, 0);
GO




-- Carregamento dos dados iniciais da tabela Manager
INSERT INTO [dbo].[Manager] (RequestId, DepartmentId, ManagerCode, ManagerFirstName, ManagerMiddleName, ManagerSurname)
VALUES
	(1, 1, 'PT-PRT-HR-000012', 'Carolina', 'Franco de', 'Lima');
GO




-- Carregamento dos dados iniciais da tabela Employee
INSERT INTO [dbo].[Employee] (RequestId, DepartmentId, EmployeeCode, EmployeeFirstName, EmployeeMiddleName, EmployeeSurname)
VALUES
	(1, 2, 'PT-PRT-TI-000120', 'Maria', 'Ant�nia de Castro e', 'S�');
GO




-- Carregamento dos dados iniciais da tabela ReportingStructure
INSERT INTO [dbo].[ReportingStructure] (EmployeeId, ManagerId)
VALUES
	(1,1);
GO
