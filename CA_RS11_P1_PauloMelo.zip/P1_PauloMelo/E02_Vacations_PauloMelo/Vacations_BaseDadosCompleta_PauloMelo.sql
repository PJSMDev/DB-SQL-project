USE [master]
GO
/****** Object:  Database [Vacations_PauloMelo]    Script Date: 4/14/2024 12:59:41 AM ******/
CREATE DATABASE [Vacations_PauloMelo]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Vacations_PauloMelo', FILENAME = N'C:\Restart11\Data\Vacations_PauloMelo.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'Vacations_PauloMelo_log', FILENAME = N'C:\Restart11\Data\Vacations_PauloMelo_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [Vacations_PauloMelo] SET COMPATIBILITY_LEVEL = 150
GO
USE [Vacations_PauloMelo]
GO
/****** Object:  Table [dbo].[Department]    Script Date: 4/14/2024 12:59:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Department](
	[DepartmentId] [int] IDENTITY(1,1) NOT NULL,
	[Department] [nvarchar](150) NOT NULL,
 CONSTRAINT [PK_Department] PRIMARY KEY CLUSTERED 
(
	[DepartmentId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 4/14/2024 12:59:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Employee](
	[EmployeeId] [int] IDENTITY(1,1) NOT NULL,
	[RequestId] [int] NOT NULL,
	[DepartmentId] [int] NOT NULL,
	[EmployeeCode] [nchar](16) NOT NULL,
	[EmployeeFirstName] [nvarchar](15) NOT NULL,
	[EmployeeMiddleName] [nvarchar](40) NOT NULL,
	[EmployeeSurname] [nvarchar](15) NOT NULL,
 CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Manager]    Script Date: 4/14/2024 12:59:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Manager](
	[ManagerId] [int] IDENTITY(1,1) NOT NULL,
	[RequestId] [int] NOT NULL,
	[DepartmentId] [int] NOT NULL,
	[ManagerCode] [nchar](16) NOT NULL,
	[ManagerFirstName] [nvarchar](15) NOT NULL,
	[ManagerMiddleName] [nvarchar](40) NOT NULL,
	[ManagerSurname] [nvarchar](15) NOT NULL,
 CONSTRAINT [PK_Manager] PRIMARY KEY CLUSTERED 
(
	[ManagerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ReportingStructure]    Script Date: 4/14/2024 12:59:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReportingStructure](
	[EmployeeId] [int] NOT NULL,
	[ManagerId] [int] NOT NULL,
 CONSTRAINT [PK_ReportingStructure] PRIMARY KEY CLUSTERED 
(
	[EmployeeId] ASC,
	[ManagerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[VacationPeriod]    Script Date: 4/14/2024 12:59:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[VacationPeriod](
	[PeriodId] [int] IDENTITY(1,1) NOT NULL,
	[RequestId] [int] NOT NULL,
	[StartDate] [date] NOT NULL,
	[EndDate] [date] NOT NULL,
	[TotalDays] [int] NOT NULL,
	[Approval] [bit] NOT NULL,
 CONSTRAINT [PK_VacationPeriod] PRIMARY KEY CLUSTERED 
(
	[PeriodId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[VacationRequest]    Script Date: 4/14/2024 12:59:41 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[VacationRequest](
	[RequestId] [int] IDENTITY(1,1) NOT NULL,
	[RequestDate] [date] NOT NULL,
	[ApprovalDate] [date] NOT NULL,
	[ManagerCode] [nchar](16) NOT NULL,
	[EmployeeCode] [nchar](16) NOT NULL,
 CONSTRAINT [PK_VacationRequest] PRIMARY KEY CLUSTERED 
(
	[RequestId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Department] ON 
GO
INSERT [dbo].[Department] ([DepartmentId], [Department]) VALUES (1, N'Recursos Humanos')
GO
INSERT [dbo].[Department] ([DepartmentId], [Department]) VALUES (2, N'Tecnologias de Informa��o')
GO
SET IDENTITY_INSERT [dbo].[Department] OFF
GO
SET IDENTITY_INSERT [dbo].[Employee] ON 
GO
INSERT [dbo].[Employee] ([EmployeeId], [RequestId], [DepartmentId], [EmployeeCode], [EmployeeFirstName], [EmployeeMiddleName], [EmployeeSurname]) VALUES (1, 1, 2, N'PT-PRT-TI-000120', N'Maria', N'Ant�nia de Castro e', N'S�')
GO
SET IDENTITY_INSERT [dbo].[Employee] OFF
GO
SET IDENTITY_INSERT [dbo].[Manager] ON 
GO
INSERT [dbo].[Manager] ([ManagerId], [RequestId], [DepartmentId], [ManagerCode], [ManagerFirstName], [ManagerMiddleName], [ManagerSurname]) VALUES (1, 1, 1, N'PT-PRT-HR-000012', N'Carolina', N'Franco de', N'Lima')
GO
SET IDENTITY_INSERT [dbo].[Manager] OFF
GO
INSERT [dbo].[ReportingStructure] ([EmployeeId], [ManagerId]) VALUES (1, 1)
GO
SET IDENTITY_INSERT [dbo].[VacationPeriod] ON 
GO
INSERT [dbo].[VacationPeriod] ([PeriodId], [RequestId], [StartDate], [EndDate], [TotalDays], [Approval]) VALUES (1, 1, CAST(N'2019-03-04' AS Date), CAST(N'2019-03-08' AS Date), 5, 1)
GO
INSERT [dbo].[VacationPeriod] ([PeriodId], [RequestId], [StartDate], [EndDate], [TotalDays], [Approval]) VALUES (2, 1, CAST(N'2019-07-29' AS Date), CAST(N'2019-08-16' AS Date), 15, 1)
GO
INSERT [dbo].[VacationPeriod] ([PeriodId], [RequestId], [StartDate], [EndDate], [TotalDays], [Approval]) VALUES (3, 1, CAST(N'2019-12-23' AS Date), CAST(N'2020-01-03' AS Date), 8, 0)
GO
SET IDENTITY_INSERT [dbo].[VacationPeriod] OFF
GO
SET IDENTITY_INSERT [dbo].[VacationRequest] ON 
GO
INSERT [dbo].[VacationRequest] ([RequestId], [RequestDate], [ApprovalDate], [ManagerCode], [EmployeeCode]) VALUES (1, CAST(N'2019-02-25' AS Date), CAST(N'2019-03-04' AS Date), N'PT-PRT-HR-000012', N'PT-PRT-TI-000120')
GO
SET IDENTITY_INSERT [dbo].[VacationRequest] OFF
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_Department] FOREIGN KEY([DepartmentId])
REFERENCES [dbo].[Department] ([DepartmentId])
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_Department]
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_VacationRequest] FOREIGN KEY([RequestId])
REFERENCES [dbo].[VacationRequest] ([RequestId])
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_VacationRequest]
GO
ALTER TABLE [dbo].[Manager]  WITH CHECK ADD  CONSTRAINT [FK_Manager_Department] FOREIGN KEY([DepartmentId])
REFERENCES [dbo].[Department] ([DepartmentId])
GO
ALTER TABLE [dbo].[Manager] CHECK CONSTRAINT [FK_Manager_Department]
GO
ALTER TABLE [dbo].[Manager]  WITH CHECK ADD  CONSTRAINT [FK_Manager_VacationRequest] FOREIGN KEY([RequestId])
REFERENCES [dbo].[VacationRequest] ([RequestId])
GO
ALTER TABLE [dbo].[Manager] CHECK CONSTRAINT [FK_Manager_VacationRequest]
GO
ALTER TABLE [dbo].[ReportingStructure]  WITH CHECK ADD  CONSTRAINT [FK_ReportingStructure_Employee] FOREIGN KEY([EmployeeId])
REFERENCES [dbo].[Employee] ([EmployeeId])
GO
ALTER TABLE [dbo].[ReportingStructure] CHECK CONSTRAINT [FK_ReportingStructure_Employee]
GO
ALTER TABLE [dbo].[ReportingStructure]  WITH CHECK ADD  CONSTRAINT [FK_ReportingStructure_Manager] FOREIGN KEY([ManagerId])
REFERENCES [dbo].[Manager] ([ManagerId])
GO
ALTER TABLE [dbo].[ReportingStructure] CHECK CONSTRAINT [FK_ReportingStructure_Manager]
GO
ALTER TABLE [dbo].[VacationPeriod]  WITH CHECK ADD  CONSTRAINT [FK_VacationPeriod_VacationRequest] FOREIGN KEY([RequestId])
REFERENCES [dbo].[VacationRequest] ([RequestId])
GO
ALTER TABLE [dbo].[VacationPeriod] CHECK CONSTRAINT [FK_VacationPeriod_VacationRequest]
GO
USE [master]
GO
ALTER DATABASE [Vacations_PauloMelo] SET  READ_WRITE 
GO
