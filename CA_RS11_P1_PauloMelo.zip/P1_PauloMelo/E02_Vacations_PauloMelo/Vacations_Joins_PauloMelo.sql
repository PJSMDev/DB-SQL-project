/*
12. Crie a consulta Vacations_Joins_Nome.sql, para juntar as tabelas de forma a produzir um resultado 
semelhante � imagem do formul�rio em papel.
*/




-- Mudan�a do contexto da database
USE [Vacations_PauloMelo];
GO




-- Consulta de jun��o de tabelas
SELECT
	v.RequestId AS 'Request form n�',
	FORMAT(v.RequestDate, 'dd-MM-yyyy') AS 'Request date',		-- Mudan�a de formato da data
	FORMAT(v.ApprovalDate, 'dd-MM-yyy') AS 'Approval date',
	v.ManagerCode AS 'Manager code',
	CONCAT_WS(' ', m.ManagerFirstName, m.ManagerMiddleName, m.ManagerSurname) AS 'Manager name',		-- Concatena��o das v�rias partes do nome
	e.EmployeeCode AS 'Employee code',
	CONCAT_WS(' ', e.EmployeeFirstName, e.EmployeeMiddleName, e.EmployeeSurname) AS 'Employee name',
	d.Department AS 'Department',
	vp.PeriodId AS '#',
	FORMAT(vp.StartDate, 'dd-MM-yyyy') AS 'Start date',
	FORMAT(vp.EndDate, 'dd-MM-yyyy') AS 'End date',
	vp.TotalDays AS 'Total days',
	IIF(vp.Approval = 1, 'Yes', 'No') AS 'Approved?'		-- Caso o valor bit seja 1, o per�odo de f�rias foi aprovado, caso seja 0, foi rejeitado
FROM
	[dbo].[VacationRequest] AS v
INNER JOIN
	[dbo].[Manager] AS m
ON
	v.RequestId = m.RequestId
INNER JOIN
	[dbo].[Employee] AS e
ON
	v.RequestId = e.RequestId
INNER JOIN
	[dbo].[Department] AS d
ON
	d.DepartmentId = e.DepartmentId
INNER JOIN
	[dbo].[VacationPeriod] AS vp
ON
	v.RequestId = vp.RequestId
GO
