/*
15. Crie o script Vacations_Atualizar_Nome.sql para atualizar o primeiro formul�rio de pedido de f�rias.
*/




-- Mudan�a do contexto da database
USE [Vacations_PauloMelo];
GO




-- Atualiza��o do ManagerMiddleName e do ManagerSurname
UPDATE [dbo].[Manager]
SET
	[ManagerMiddleName] = 'Lima de', 
	[ManagerSurname] = 'Fran�a'
WHERE
	[ManagerId] = 1;




-- Atualiza��o do EmployeeCode
UPDATE [dbo].[Employee]
SET
	[EmployeeCode] = 'PT-PRT-SI-000120'
WHERE
	EmployeeId = 1;




-- Atualiza��o do Department
UPDATE [dbo].[Department]
SET
	[Department] = 'Sistemas de Informa��o'
WHERE
	[DepartmentId] = 2;




-- Atualiza��o da EndDate, TotalDays e Approval
UPDATE [dbo].[VacationPeriod]
SET
	[EndDate] = '2019-12-31',		-- Mantive o formato da data que tinha usado at� agora
	[TotalDays] = 7,
	[Approval] = 1		-- Mantive o formato bit para a aprova��o, ou n�o, dos pedidos de f�rias
WHERE
	[PeriodId] = 3;
