-- Mudan�a do contexto da database
USE [MarketDev_RS_P1];
GO




/*
21. Listagem dos produtos por cor, categoria e subcategoria
	295 registos
*/
SELECT
	IIF(p.Color IS NULL, '<...>', p.Color) AS 'Color',		-- Para mudar o aspeto do resultado
	c.CategoryName AS 'Category',
	s.SubcategoryName AS 'Subcategory',
	p.ProductName AS 'Product',
	IIF(p.Size IS NULL, '', p.Size) AS 'Size unit'		-- Para mudar o aspeto do resultado
FROM
	[Marketing].[Product] AS p
INNER JOIN
	[Marketing].[Subcategory] AS s
ON
	p.SubcategoryID = s.SubcategoryID
INNER JOIN
	[Marketing].[Category] AS c
ON
	s.CategoryID = c.CategoryID
ORDER BY
	'Color',
	'Category',
	'Subcategory';
GO




/*
22. Listagem do tempo de venda dos produtos
	86 registos
*/
SELECT
	DATEDIFF(YEAR, s.SellStartDate, s.SellEndDate) AS 'Sell years',
	DATEDIFF(MONTH, s.SellStartDate, s.SellEndDate) AS 'Sell months',
	DATEDIFF(DAY, s.SellStartDate, s.SellEndDate) AS 'Sell days',
	FORMAT(s.SellStartDate, 'dd/MM/yyyy') AS 'Sell start',
	FORMAT(s.SellEndDate, 'dd/MM/yyyy') AS 'Sell end',
	s.ProductName AS 'Product',
	FORMAT(s.ListPrice, 'c', 'pt-pt') AS 'List price'
FROM
	[Marketing].[Product] AS s
WHERE
	s.SellStartDate IS NOT NULL
	AND s.SellEndDate IS NOT NULL
ORDER BY
	'Sell years' DESC,
	'Product';
GO




/*
23. Estat�sticas dos pre�os dos produtos mais representativos, pelo menos 10, agrupados por cor:
	5 registos
*/
SELECT
    COUNT (*) AS 'Total',		-- Conta o n�mero de registos
    p.Color AS 'Color',
    FORMAT(MIN(p.ListPrice), 'c', 'pt-pt') AS 'Minimum price',
    FORMAT(MAX(p.ListPrice), 'c', 'pt-pt') AS 'Maximum price',
    FORMAT(AVG(p.ListPrice), 'c', 'pt-pt') AS 'Average price'
FROM
    [Marketing].[Product] AS p
WHERE
	p.Color IS NOT NULL		-- Objetos sem cor n�o podem ser agrupados
GROUP BY
    p.Color		-- Agrupa por cor
HAVING
    COUNT (*) >= 10		-- Pelo menos 10
ORDER BY
    COUNT (*) DESC;
GO




/*
24. Listagem dos vendedores europeus com e-mail autom�tico
	3 registos
*/
SELECT
	CONCAT_WS(' ', sp.FirstName, UPPER(sp.LastName)) AS 'Salesperson',		-- Nome completo
	CONCAT(						-- Para evitar o uso de vari�veis
		LOWER(sp.FirstName),	-- Continua a ser reutiliz�vel
		'.',
		LOWER(sp.LastName),
		'_',
		REPLACE(LOWER(st.Country), ' ', ''),	-- Substituir espa�os por espa�os vazios para os eliminar
		'.',
		REPLACE((LOWER(st.Region)), ' ', ''),
		'@restart.com'
	) AS 'E-mail',
	st.Country AS 'Country',
	st.Region AS 'Region'
FROM
	[Marketing].[Salesperson] AS sp
INNER JOIN
	[Marketing].[SalesTerritory] AS st
ON
	st.SalesTerritoryID = sp.SalesTerritoryID
WHERE
	st.Region = 'EUROPE'
ORDER BY
	st.Country DESC;
GO




/*
25. Contagem dos vendedores por pa�s e por regi�o
	6 registos
*/
SELECT
	st.Region AS 'Region',
	st.Country AS 'Country',
	COUNT(sp.SalespersonID) AS 'Total salesperson'
FROM
	[Marketing].[Salesperson] as sp
INNER JOIN
	[Marketing].[SalesTerritory] as st
ON
	st.SalesTerritoryID = sp.SalesTerritoryID
GROUP BY
	st.Region,
	st.Country
ORDER BY
	st.Region;
GO




/*
26. Prospetores que t�m de atualizar, por telefone, o email
	5.189 registos
*/
SELECT
	CONCAT_WS(' ', p.FirstName, p.MiddleName, p.LastName) AS 'Prospecter',
	COALESCE(p.CellPhoneNumber, p.HomePhoneNumber, p.WorkPhoneNumber) AS 'Contact number',		-- Usa os contactos pela seguinte ordem, se poss�vel: telem�vel, casa, trabalho
	COALESCE(p.EmailAddress, '<to be updated>') AS 'E-mail'		-- Talvez bastasse imprimir a string diretamente. Uso desnecess�rio de recursos?
FROM
	[Marketing].[Prospect] AS p
WHERE
	p.EmailAddress is NULL
ORDER BY
	'Prospecter';
GO




/*
27. Quais os modelos que n�o t�m produtos
	1 registo
*/
SELECT 
    pm.ProductModel AS 'Product model',
    pm.Description AS 'Product description'
FROM 
    [Marketing].[ProductModel] AS pm
LEFT OUTER JOIN								-- Todas as linhas de ProductModel mesmo que n�o haja correspond�ncia com ProductDescription
   [Marketing].[ProductDescription] AS pd 
ON
	pm.ProductModelID = pd.ProductModelID
WHERE 
    pd.ProductDescriptionID IS NULL;		-- Apenas as linhas sem descri��o, se n�o tem descri��o, n�o tem produto
GO




/*
28. Listagem multil�ngua das bicicletas
	30 registos
*/
SELECT
    pm.ProductModel AS 'Product model',
	p.ProductName AS 'Product',
    p.ProductNumber AS 'Product nr.',
	l.LanguageName AS 'Language',
    pd.Description AS 'Product description'
FROM 
    [Marketing].[Product] AS p
INNER JOIN 
    [Marketing].[ProductModel] AS pm
ON 
	p.ProductModelID = pm.ProductModelID
INNER JOIN 
	[Marketing].[ProductDescription] AS pd
ON 
	pd.ProductModelID = pm.ProductModelID
INNER JOIN
	[Marketing].[Language] AS l
ON
	l.LanguageID = pd.LanguageID
WHERE
	pm.ProductModel LIKE '%Bike%'
ORDER BY 
    pm.ProductModel,
	l.LanguageName;
GO




/*
29. Listagens das l�nguas e respetivo c�digo ISO
	7 registos
*/
SELECT
    l.LanguageName AS 'Language name',
	l.LanguageID AS 'ISO language code'
FROM
    [Marketing].[Language] AS l
WHERE
    l.LanguageID <> ''     -- Se a LanguageId n�o � vazia, ent�o tem de ser apresentada
ORDER BY
	l.LanguageName;
GO




/*
30. Data prevista de entrega dos produtos
	104 registos
*/
SELECT
	p.ProductName AS 'Product',
	p.DaysToManufacture AS 'Days to manufacture'
FROM
	[Marketing].[Product] AS p
GO



SELECT
    p.ProductName AS 'Product',
    p.DaysToManufacture AS 'Days to manufacture',
    FORMAT(DATEADD(DAY, p.DaysToManufacture, GETDATE()), 'dd/MM/yyyy') AS 'Estimated delivery date'		-- N�o consegui perceber qual seria a data � qual seriam acrescitados os dias necess�rios para produ��o por isso usei a data e hora atuais
FROM
    [Marketing].[Product] AS p
WHERE
	p.DaysToManufacture >= 2;
GO

/*
SELECT
    p.ProductName AS 'Product',
    p.DaysToManufacture AS 'Days to manufacture',
    FORMAT(DATEADD(DAY, p.DaysToManufacture, p.SellStartDate), 'dd/MM/yyyy') AS 'Estimated delivery date'
FROM
    [Marketing].[Product] AS p
WHERE
	p.DaysToManufacture >= 2;
GO
*/